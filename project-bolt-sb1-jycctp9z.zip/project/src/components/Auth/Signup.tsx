import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, ToggleLeft, ToggleRight } from 'lucide-react';
import { authAPI, adminAPI } from '../../services/api';
import { ServiceEntity } from '../../types';

const Signup: React.FC = () => {
  const [isProvider, setIsProvider] = useState(false);
  const [services, setServices] = useState<ServiceEntity[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  
  const navigate = useNavigate();

  const [customerForm, setCustomerForm] = useState({
    username: '',
    password: '',
    customerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: ''
  });

  const [providerForm, setProviderForm] = useState({
    username: '',
    password: '',
    providerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: '',
    serviceId: '',
    experience: '',
    description: ''
  });

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const servicesData = await adminAPI.getAllServices();
      setServices(servicesData);
    } catch (err) {
      console.error('Failed to fetch services:', err);
    }
  };

  const validatePassword = (password: string) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(password);
  };

  const validateUsername = (username: string) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/;
    return regex.test(username);
  };

  const validateName = (name: string) => {
    const regex = /^[A-Za-z\s]+$/;
    return regex.test(name);
  };

  const validateMobile = (mobile: string) => {
    const regex = /^\d{10}$/;
    return regex.test(mobile);
  };

  const validateEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validateUsername(customerForm.username)) {
      setError('Username must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character');
      return;
    }

    if (!validatePassword(customerForm.password)) {
      setError('Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character');
      return;
    }

    if (!validateName(customerForm.customerName)) {
      setError('Name must contain only letters and spaces');
      return;
    }

    if (!validateName(customerForm.location)) {
      setError('Location must contain only letters and spaces');
      return;
    }

    if (!validateMobile(customerForm.mobileNumber)) {
      setError('Mobile number must be exactly 10 digits');
      return;
    }

    if (customerForm.email && !validateEmail(customerForm.email)) {
      setError('Please enter a valid email address');
      return;
    }

    setLoading(true);

    try {
      const registerData = {
        username: customerForm.username,
        password: customerForm.password,
        role: 'ROLE_CUSTOMER' as const,
        isDeleted: false,
        customerName: customerForm.customerName,
        location: customerForm.location,
        mobileNumber: parseInt(customerForm.mobileNumber),
        email: customerForm.email || undefined,
        profilePicture: customerForm.profilePicture || undefined
      };

      await authAPI.registerCustomer(registerData);
      setSuccess('Customer registered successfully! Please login.');
      setTimeout(() => navigate('/login'), 2000);
    } catch (err: any) {
      setError(err.response?.data || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const handleProviderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validateUsername(providerForm.username)) {
      setError('Username must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character');
      return;
    }

    if (!validatePassword(providerForm.password)) {
      setError('Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character');
      return;
    }

    if (!validateName(providerForm.providerName)) {
      setError('Name must contain only letters and spaces');
      return;
    }

    if (!validateName(providerForm.location)) {
      setError('Location must contain only letters and spaces');
      return;
    }

    if (!validateMobile(providerForm.mobileNumber)) {
      setError('Mobile number must be exactly 10 digits');
      return;
    }

    if (providerForm.email && !validateEmail(providerForm.email)) {
      setError('Please enter a valid email address');
      return;
    }

    if (providerForm.description.length > 300) {
      setError('Description must be maximum 300 characters');
      return;
    }

    setLoading(true);

    try {
      const selectedService = services.find(s => s.serviceId === providerForm.serviceId);
      if (!selectedService) {
        setError('Please select a valid service');
        return;
      }

      const registerData = {
        username: providerForm.username,
        password: providerForm.password,
        role: 'ROLE_PROVIDER' as const,
        isDeleted: false,
        providerName: providerForm.providerName,
        location: providerForm.location,
        mobileNumber: parseInt(providerForm.mobileNumber),
        email: providerForm.email || undefined,
        profilePicture: providerForm.profilePicture || undefined,
        service: selectedService,
        experience: parseInt(providerForm.experience),
        description: providerForm.description
      };

      await authAPI.registerProvider(registerData);
      setSuccess('Provider registered successfully! Please login.');
      setTimeout(() => navigate('/login'), 2000);
    } catch (err: any) {
      setError(err.response?.data || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Create Account</h2>
          <p className="text-gray-600 mt-2">Join our community today</p>
        </div>

        {/* Toggle Button */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-4 bg-gray-100 rounded-lg p-2">
            <span className={`font-medium ${!isProvider ? 'text-blue-600' : 'text-gray-600'}`}>
              Customer
            </span>
            <button
              onClick={() => setIsProvider(!isProvider)}
              className="text-blue-600"
            >
              {isProvider ? <ToggleRight size={24} /> : <ToggleLeft size={24} />}
            </button>
            <span className={`font-medium ${isProvider ? 'text-blue-600' : 'text-gray-600'}`}>
              Provider
            </span>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm mb-6">
            {error}
          </div>
        )}

        {success && (
          <div className="bg-green-50 text-green-700 p-3 rounded-lg text-sm mb-6">
            {success}
          </div>
        )}

        {!isProvider ? (
          /* Customer Form */
          <form onSubmit={handleCustomerSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Username *
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={customerForm.username}
                  onChange={(e) => setCustomerForm({ ...customerForm, username: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                    value={customerForm.password}
                    onChange={(e) => setCustomerForm({ ...customerForm, password: e.target.value })}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-5 w-5 text-gray-400" /> : <Eye className="h-5 w-5 text-gray-400" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Customer Name *
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={customerForm.customerName}
                  onChange={(e) => setCustomerForm({ ...customerForm, customerName: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location *
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={customerForm.location}
                  onChange={(e) => setCustomerForm({ ...customerForm, location: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mobile Number *
                </label>
                <input
                  type="tel"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={customerForm.mobileNumber}
                  onChange={(e) => setCustomerForm({ ...customerForm, mobileNumber: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={customerForm.email}
                  onChange={(e) => setCustomerForm({ ...customerForm, email: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Profile Picture URL
              </label>
              <input
                type="url"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={customerForm.profilePicture}
                onChange={(e) => setCustomerForm({ ...customerForm, profilePicture: e.target.value })}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 transition-colors duration-200"
            >
              {loading ? 'Creating Account...' : 'Create Customer Account'}
            </button>
          </form>
        ) : (
          /* Provider Form */
          <form onSubmit={handleProviderSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Username *
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={providerForm.username}
                  onChange={(e) => setProviderForm({ ...providerForm, username: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                    value={providerForm.password}
                    onChange={(e) => setProviderForm({ ...providerForm, password: e.target.value })}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-5 w-5 text-gray-400" /> : <Eye className="h-5 w-5 text-gray-400" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Provider Name *
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={providerForm.providerName}
                  onChange={(e) => setProviderForm({ ...providerForm, providerName: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location *
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={providerForm.location}
                  onChange={(e) => setProviderForm({ ...providerForm, location: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mobile Number *
                </label>
                <input
                  type="tel"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={providerForm.mobileNumber}
                  onChange={(e) => setProviderForm({ ...providerForm, mobileNumber: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={providerForm.email}
                  onChange={(e) => setProviderForm({ ...providerForm, email: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Occupation *
                </label>
                <select
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={providerForm.serviceId}
                  onChange={(e) => setProviderForm({ ...providerForm, serviceId: e.target.value })}
                >
                  <option value="">Select Service</option>
                  {services.map((service) => (
                    <option key={service.serviceId} value={service.serviceId}>
                      {service.serviceName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Experience (Years) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={providerForm.experience}
                  onChange={(e) => setProviderForm({ ...providerForm, experience: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Profile Picture URL
              </label>
              <input
                type="url"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={providerForm.profilePicture}
                onChange={(e) => setProviderForm({ ...providerForm, profilePicture: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description (Max 300 characters) *
              </label>
              <textarea
                required
                maxLength={300}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={providerForm.description}
                onChange={(e) => setProviderForm({ ...providerForm, description: e.target.value })}
              />
              <div className="text-right text-sm text-gray-500 mt-1">
                {providerForm.description.length}/300
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 transition-colors duration-200"
            >
              {loading ? 'Creating Account...' : 'Create Provider Account'}
            </button>
          </form>
        )}

        <div className="mt-6 text-center">
          <p className="text-gray-600">
            Already have an account?{' '}
            <Link to="/login" className="text-blue-600 hover:text-blue-700 font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;