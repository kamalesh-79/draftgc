import React from 'react';
import { ArrowLeft, Users, Target, Award } from 'lucide-react';
import { Link } from 'react-router-dom';

const About: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link
            to="/"
            className="inline-flex items-center text-blue-600 hover:text-blue-700"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Home
          </Link>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About GoLocal</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Connecting communities through trusted local services. We bridge the gap between 
            skilled service providers and customers who need reliable, quality services.
          </p>
        </div>

        {/* Application Overview */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-12">
          <h2 className="text-3xl font-semibold text-gray-900 mb-6">Our Platform</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">For Customers</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Easy registration and profile management</li>
                <li>• Search and discover local service providers</li>
                <li>• Book services with transparent pricing</li>
                <li>• Rate and review service providers</li>
                <li>• Track booking history and status</li>
                <li>• Secure and reliable platform</li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">For Service Providers</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Professional profile creation</li>
                <li>• Showcase skills and experience</li>
                <li>• Receive and manage booking requests</li>
                <li>• Build customer relationships</li>
                <li>• Grow your local business</li>
                <li>• Verified and trusted platform</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <Target className="w-12 h-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3">Our Mission</h3>
            <p className="text-gray-700">
              To empower local communities by connecting skilled service providers 
              with customers who value quality and reliability.
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <Users className="w-12 h-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3">Our Vision</h3>
            <p className="text-gray-700">
              To become the most trusted platform for local services, 
              fostering economic growth in communities worldwide.
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <Award className="w-12 h-12 text-purple-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3">Our Values</h3>
            <p className="text-gray-700">
              Trust, quality, community support, and innovation drive 
              everything we do to serve our users better.
            </p>
          </div>
        </div>

        {/* Team Details */}
        <div className="bg-white rounded-lg shadow-md p-8">
          <h2 className="text-3xl font-semibold text-gray-900 mb-8 text-center">Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-24 h-24 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">JD</span>
              </div>
              <h3 className="text-lg font-semibold">John Doe</h3>
              <p className="text-gray-600">CEO & Founder</p>
              <p className="text-sm text-gray-500 mt-2">
                Visionary leader with 10+ years in tech
              </p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">JS</span>
              </div>
              <h3 className="text-lg font-semibold">Jane Smith</h3>
              <p className="text-gray-600">CTO</p>
              <p className="text-sm text-gray-500 mt-2">
                Technical expert in platform development
              </p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">MJ</span>
              </div>
              <h3 className="text-lg font-semibold">Mike Johnson</h3>
              <p className="text-gray-600">Head of Operations</p>
              <p className="text-sm text-gray-500 mt-2">
                Operations specialist ensuring smooth service
              </p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">SW</span>
              </div>
              <h3 className="text-lg font-semibold">Sarah Wilson</h3>
              <p className="text-gray-600">Head of Marketing</p>
              <p className="text-sm text-gray-500 mt-2">
                Marketing strategist building community connections
              </p>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg p-8 text-white text-center mt-12">
          <h2 className="text-2xl font-semibold mb-4">Get in Touch</h2>
          <p className="text-blue-100 mb-6">
            Have questions or want to join our platform? We'd love to hear from you!
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-blue-100">contact@golocal.com</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Phone</h3>
              <p className="text-blue-100">+1 (555) 123-4567</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Address</h3>
              <p className="text-blue-100">123 Tech Street, Innovation City</p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">GoLocal</h3>
            <p className="text-gray-300">Connecting communities through trusted services</p>
            <p className="text-gray-400 mt-4">&copy; 2024 GoLocal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;