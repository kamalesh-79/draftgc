import React, { useState } from 'react';
import Navbar from '../Layout/Navbar';
import { adminAPI } from '../../services/api';

const AdminUpdatePassword: React.FC = () => {
  const [formData, setFormData] = useState({
    username: '',
    newPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const navLinks = [
    { label: 'Home', path: '/admin/dashboard' },
    { label: 'Customers', path: '/admin/customers' },
    { label: 'Providers', path: '/admin/providers' },
    { label: 'Services', path: '/admin/services' },
    { label: 'Bookings', path: '/admin/bookings' },
    { label: 'Update Password', path: '/admin/update-password' },
    { label: 'About', path: '/about' }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      await adminAPI.updatePassword(formData.username, formData.newPassword);
      setMessage('Password updated successfully!');
      setFormData({ username: '', newPassword: '' });
    } catch (err) {
      console.error('Failed to update password:', err);
      setMessage('Failed to update password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Admin" links={navLinks} />
      
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-semibold mb-6">Update User Password</h2>
          
          {message && (
            <div className={`p-3 rounded-lg text-sm mb-6 ${
              message.includes('successfully') 
                ? 'bg-green-50 text-green-700' 
                : 'bg-red-50 text-red-700'
            }`}>
              {message}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Username *
              </label>
              <input
                type="text"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                New Password *
              </label>
              <input
                type="password"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={formData.newPassword}
                onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 transition-colors duration-200"
            >
              {loading ? 'Updating...' : 'Update Password'}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
};

export default AdminUpdatePassword;