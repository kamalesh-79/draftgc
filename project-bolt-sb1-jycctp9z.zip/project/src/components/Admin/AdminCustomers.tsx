import React, { useState, useEffect } from 'react';
import { Search, Plus, Edit, Trash2 } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { adminAPI } from '../../services/api';
import { Customer } from '../../types';

const AdminCustomers: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([]);
  const [activeTab, setActiveTab] = useState('list');
  const [searchId, setSearchId] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  
  // Forms
  const [createForm, setCreateForm] = useState({
    username: '',
    password: '',
    customerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: ''
  });

  const [updateForm, setUpdateForm] = useState({
    customerId: '',
    customerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: ''
  });

  const [deleteId, setDeleteId] = useState('');

  const navLinks = [
    { label: 'Home', path: '/admin/dashboard' },
    { label: 'Customers', path: '/admin/customers' },
    { label: 'Providers', path: '/admin/providers' },
    { label: 'Services', path: '/admin/services' },
    { label: 'Bookings', path: '/admin/bookings' },
    { label: 'Update Password', path: '/admin/update-password' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchCustomers();
  }, []);

  useEffect(() => {
    if (searchId) {
      const filtered = customers.filter(customer =>
        customer.username.toLowerCase().includes(searchId.toLowerCase())
      );
      setFilteredCustomers(filtered);
    } else {
      setFilteredCustomers(customers);
    }
  }, [customers, searchId]);

  const fetchCustomers = async () => {
    try {
      const customersData = await adminAPI.getAllCustomers();
      setCustomers(customersData);
    } catch (err) {
      console.error('Failed to fetch customers:', err);
    }
  };

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await adminAPI.createCustomer({
        username: createForm.username,
        password: createForm.password,
        role: 'ROLE_CUSTOMER',
        isDeleted: false,
        customerName: createForm.customerName,
        location: createForm.location,
        mobileNumber: parseInt(createForm.mobileNumber),
        email: createForm.email || undefined,
        profilePicture: createForm.profilePicture || undefined
      });
      
      setCreateForm({
        username: '',
        password: '',
        customerName: '',
        location: '',
        mobileNumber: '',
        email: '',
        profilePicture: ''
      });
      
      fetchCustomers();
      alert('Customer created successfully!');
    } catch (err) {
      console.error('Failed to create customer:', err);
      alert('Failed to create customer');
    }
  };

  const handleUpdateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await adminAPI.updateCustomer(updateForm.customerId, {
        username: updateForm.customerId,
        customerName: updateForm.customerName,
        location: updateForm.location,
        mobileNumber: parseInt(updateForm.mobileNumber),
        email: updateForm.email || undefined,
        profilePicture: updateForm.profilePicture || undefined
      });
      
      setUpdateForm({
        customerId: '',
        customerName: '',
        location: '',
        mobileNumber: '',
        email: '',
        profilePicture: ''
      });
      
      fetchCustomers();
      alert('Customer updated successfully!');
    } catch (err) {
      console.error('Failed to update customer:', err);
      alert('Failed to update customer');
    }
  };

  const handleDeleteCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await adminAPI.deleteCustomer(deleteId);
      setDeleteId('');
      fetchCustomers();
      alert('Customer deleted successfully!');
    } catch (err) {
      console.error('Failed to delete customer:', err);
      alert('Failed to delete customer');
    }
  };

  const loadCustomerForUpdate = (customer: Customer) => {
    setUpdateForm({
      customerId: customer.username,
      customerName: customer.customerName,
      location: customer.location,
      mobileNumber: customer.mobileNumber.toString(),
      email: customer.email || '',
      profilePicture: customer.profilePicture || ''
    });
    setActiveTab('update');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Admin" links={navLinks} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('list')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'list'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Customer List
              </button>
              <button
                onClick={() => setActiveTab('create')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'create'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Create Customer
              </button>
              <button
                onClick={() => setActiveTab('update')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'update'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Update Customer
              </button>
              <button
                onClick={() => setActiveTab('delete')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'delete'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Delete Customer
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'list' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-semibold">Customer List</h2>
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search by Customer ID"
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={searchId}
                        onChange={(e) => setSearchId(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Username
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Customer Name
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Mobile Number
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Email
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          No. of Bookings
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredCustomers.map((customer) => (
                        <tr key={customer.username} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {customer.username}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {customer.customerName}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {customer.mobileNumber}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {customer.email || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {customer.noOfBookings}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => loadCustomerForUpdate(customer)}
                              className="text-blue-600 hover:text-blue-900 mr-3"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'create' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Create New Customer</h2>
                <form onSubmit={handleCreateCustomer} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Username *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.username}
                        onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Password *
                      </label>
                      <input
                        type="password"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.password}
                        onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Customer Name *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.customerName}
                        onChange={(e) => setCreateForm({ ...createForm, customerName: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Location *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.location}
                        onChange={(e) => setCreateForm({ ...createForm, location: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Mobile Number *
                      </label>
                      <input
                        type="tel"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.mobileNumber}
                        onChange={(e) => setCreateForm({ ...createForm, mobileNumber: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email
                      </label>
                      <input
                        type="email"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.email}
                        onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Profile Picture URL
                    </label>
                    <input
                      type="url"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={createForm.profilePicture}
                      onChange={(e) => setCreateForm({ ...createForm, profilePicture: e.target.value })}
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
                  >
                    Create Customer
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'update' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Update Customer</h2>
                <form onSubmit={handleUpdateCustomer} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Customer ID *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.customerId}
                        onChange={(e) => setUpdateForm({ ...updateForm, customerId: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Customer Name *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.customerName}
                        onChange={(e) => setUpdateForm({ ...updateForm, customerName: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Location *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.location}
                        onChange={(e) => setUpdateForm({ ...updateForm, location: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Mobile Number *
                      </label>
                      <input
                        type="tel"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.mobileNumber}
                        onChange={(e) => setUpdateForm({ ...updateForm, mobileNumber: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email
                      </label>
                      <input
                        type="email"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.email}
                        onChange={(e) => setUpdateForm({ ...updateForm, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Profile Picture URL
                      </label>
                      <input
                        type="url"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.profilePicture}
                        onChange={(e) => setUpdateForm({ ...updateForm, profilePicture: e.target.value })}
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
                  >
                    Update Customer
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'delete' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Delete Customer</h2>
                <form onSubmit={handleDeleteCustomer} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Customer ID *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Enter customer ID to delete"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      value={deleteId}
                      onChange={(e) => setDeleteId(e.target.value)}
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700"
                  >
                    Delete Customer
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminCustomers;