import React, { useState, useEffect } from 'react';
import { Users, UserCheck, Briefcase, Calendar } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { adminAPI } from '../../services/api';
import { Customer, Provider, ServiceEntity, Booking } from '../../types';

const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    totalCustomers: 0,
    totalProviders: 0,
    totalServices: 0,
    totalBookings: 0
  });

  const navLinks = [
    { label: 'Home', path: '/admin/dashboard' },
    { label: 'Customers', path: '/admin/customers' },
    { label: 'Providers', path: '/admin/providers' },
    { label: 'Services', path: '/admin/services' },
    { label: 'Bookings', path: '/admin/bookings' },
    { label: 'Update Password', path: '/admin/update-password' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const [customers, providers, services, bookings] = await Promise.all([
        adminAPI.getAllCustomers(),
        adminAPI.getAllProviders(),
        adminAPI.getAllServices(),
        adminAPI.getAllBookings()
      ]);

      setStats({
        totalCustomers: customers.length,
        totalProviders: providers.length,
        totalServices: services.length,
        totalBookings: bookings.length
      });
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  return (
    
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Admin" links={navLinks} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg p-8 text-white mb-8">
          <h1 className="text-4xl font-bold mb-4">Admin Dashboard</h1>
          <p className="text-xl">Manage your GoLocal platform efficiently</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Users className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h3 className="text-3xl font-bold text-gray-900">{stats.totalCustomers}</h3>
                <p className="text-gray-600">Total Customers</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <UserCheck className="w-8 h-8 text-green-600 mr-3" />
              <div>
                <h3 className="text-3xl font-bold text-gray-900">{stats.totalProviders}</h3>
                <p className="text-gray-600">Total Providers</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Briefcase className="w-8 h-8 text-purple-600 mr-3" />
              <div>
                <h3 className="text-3xl font-bold text-gray-900">{stats.totalServices}</h3>
                <p className="text-gray-600">Total Services</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Calendar className="w-8 h-8 text-orange-600 mr-3" />
              <div>
                <h3 className="text-3xl font-bold text-gray-900">{stats.totalBookings}</h3>
                <p className="text-gray-600">Total Bookings</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">Customer Management</h3>
            <p className="text-gray-600 mb-4">Manage customer accounts, view profiles, and handle customer-related operations.</p>
            <a
              href="/admin/customers"
              className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              Manage Customers
            </a>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">Provider Management</h3>
            <p className="text-gray-600 mb-4">Oversee service providers, verify credentials, and manage provider listings.</p>
            <a
              href="/admin/providers"
              className="inline-block bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              Manage Providers
            </a>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">Service Categories</h3>
            <p className="text-gray-600 mb-4">Add new service types, manage existing categories, and organize services.</p>
            <a
              href="/admin/services"
              className="inline-block bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors duration-200"
            >
              Manage Services
            </a>
          </div>
        </div>

        {/* Application Details */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-semibold mb-6">Application Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-medium mb-4">Platform Features</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Customer registration and profile management</li>
                <li>• Service provider onboarding and verification</li>
                <li>• Real-time booking and scheduling system</li>
                <li>• Rating and review system</li>
                <li>• Location-based service discovery</li>
                <li>• Secure payment processing</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-4">Admin Capabilities</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Complete user management (CRUD operations)</li>
                <li>• Service category management</li>
                <li>• Booking oversight and monitoring</li>
                <li>• System analytics and reporting</li>
                <li>• Password management for all users</li>
                <li>• Platform configuration and settings</li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">GoLocal Admin Panel</h3>
            <p className="text-gray-300">Comprehensive platform management</p>
            <p className="text-gray-400 mt-4">&copy; 2024 GoLocal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default AdminDashboard;