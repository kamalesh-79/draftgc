import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { adminAPI } from '../../services/api';
import { ServiceEntity } from '../../types';

const AdminServices: React.FC = () => {
  const [services, setServices] = useState<ServiceEntity[]>([]);
  const [filteredServices, setFilteredServices] = useState<ServiceEntity[]>([]);
  const [activeTab, setActiveTab] = useState('list');
  const [searchId, setSearchId] = useState('');
  
  // Forms
  const [createForm, setCreateForm] = useState({
    serviceId: '',
    serviceName: ''
  });

  const navLinks = [
    { label: 'Home', path: '/admin/dashboard' },
    { label: 'Customers', path: '/admin/customers' },
    { label: 'Providers', path: '/admin/providers' },
    { label: 'Services', path: '/admin/services' },
    { label: 'Bookings', path: '/admin/bookings' },
    { label: 'Update Password', path: '/admin/update-password' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchServices();
  }, []);

  useEffect(() => {
    if (searchId) {
      const filtered = services.filter(service =>
        service.serviceId.toLowerCase().includes(searchId.toLowerCase())
      );
      setFilteredServices(filtered);
    } else {
      setFilteredServices(services);
    }
  }, [services, searchId]);

  const fetchServices = async () => {
    try {
      const servicesData = await adminAPI.getAllServices();
      setServices(servicesData);
    } catch (err) {
      console.error('Failed to fetch services:', err);
    }
  };

  const validateServiceId = (serviceId: string) => {
    const regex = /^[A-Z]{1,3}$/;
    return regex.test(serviceId);
  };

  const handleCreateService = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateServiceId(createForm.serviceId)) {
      alert('Service ID must contain only capital letters (max 3 letters)');
      return;
    }

    try {
      await adminAPI.createService({
        serviceId: createForm.serviceId,
        serviceName: createForm.serviceName
      });
      
      setCreateForm({
        serviceId: '',
        serviceName: ''
      });
      
      fetchServices();
      alert('Service created successfully!');
    } catch (err) {
      console.error('Failed to create service:', err);
      alert('Failed to create service');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Admin" links={navLinks} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('list')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'list'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Service List
              </button>
              <button
                onClick={() => setActiveTab('create')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'create'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Create Service
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'list' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-semibold">Service List</h2>
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search by Service ID"
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={searchId}
                        onChange={(e) => setSearchId(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Service ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Service Name
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          No. of Providers
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredServices.map((service) => (
                        <tr key={service.serviceId} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {service.serviceId}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {service.serviceName}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {service.noOfProviders}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'create' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Create New Service</h2>
                <form onSubmit={handleCreateService} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Service ID * (Only capital letters, max 3 letters)
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={3}
                        pattern="[A-Z]{1,3}"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.serviceId}
                        onChange={(e) => setCreateForm({ ...createForm, serviceId: e.target.value.toUpperCase() })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Service Name *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.serviceName}
                        onChange={(e) => setCreateForm({ ...createForm, serviceName: e.target.value })}
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
                  >
                    Create Service
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminServices;