import React, { useState, useEffect } from 'react';
import { Search, Edit, Trash2 } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { adminAPI } from '../../services/api';
import { Provider, ServiceEntity } from '../../types';

const AdminProviders: React.FC = () => {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [filteredProviders, setFilteredProviders] = useState<Provider[]>([]);
  const [services, setServices] = useState<ServiceEntity[]>([]);
  const [activeTab, setActiveTab] = useState('list');
  const [searchId, setSearchId] = useState('');
  
  // Forms
  const [createForm, setCreateForm] = useState({
    username: '',
    password: '',
    providerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: '',
    serviceId: '',
    experience: '',
    description: ''
  });

  const [updateForm, setUpdateForm] = useState({
    providerId: '',
    providerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: '',
    serviceId: '',
    experience: '',
    description: ''
  });

  const [deleteId, setDeleteId] = useState('');

  const navLinks = [
    { label: 'Home', path: '/admin/dashboard' },
    { label: 'Customers', path: '/admin/customers' },
    { label: 'Providers', path: '/admin/providers' },
    { label: 'Services', path: '/admin/services' },
    { label: 'Bookings', path: '/admin/bookings' },
    { label: 'Update Password', path: '/admin/update-password' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchProviders();
    fetchServices();
  }, []);

  useEffect(() => {
    if (searchId) {
      const filtered = providers.filter(provider =>
        provider.username.toLowerCase().includes(searchId.toLowerCase())
      );
      setFilteredProviders(filtered);
    } else {
      setFilteredProviders(providers);
    }
  }, [providers, searchId]);

  const fetchProviders = async () => {
    try {
      const providersData = await adminAPI.getAllProviders();
      setProviders(providersData);
    } catch (err) {
      console.error('Failed to fetch providers:', err);
    }
  };

  const fetchServices = async () => {
    try {
      const servicesData = await adminAPI.getAllServices();
      setServices(servicesData);
    } catch (err) {
      console.error('Failed to fetch services:', err);
    }
  };

  const handleCreateProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const selectedService = services.find(s => s.serviceId === createForm.serviceId);
      if (!selectedService) {
        alert('Please select a valid service');
        return;
      }

      await adminAPI.createProvider({
        username: createForm.username,
        password: createForm.password,
        role: 'ROLE_PROVIDER',
        isDeleted: false,
        providerName: createForm.providerName,
        location: createForm.location,
        mobileNumber: parseInt(createForm.mobileNumber),
        email: createForm.email || undefined,
        profilePicture: createForm.profilePicture || undefined,
        service: selectedService,
        experience: parseInt(createForm.experience),
        description: createForm.description
      });
      
      setCreateForm({
        username: '',
        password: '',
        providerName: '',
        location: '',
        mobileNumber: '',
        email: '',
        profilePicture: '',
        serviceId: '',
        experience: '',
        description: ''
      });
      
      fetchProviders();
      alert('Provider created successfully!');
    } catch (err) {
      console.error('Failed to create provider:', err);
      alert('Failed to create provider');
    }
  };

  const handleUpdateProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const selectedService = services.find(s => s.serviceId === updateForm.serviceId);
      if (!selectedService) {
        alert('Please select a valid service');
        return;
      }

      await adminAPI.updateProvider(updateForm.providerId, {
        username: updateForm.providerId,
        providerName: updateForm.providerName,
        location: updateForm.location,
        mobileNumber: parseInt(updateForm.mobileNumber),
        email: updateForm.email || undefined,
        profilePicture: updateForm.profilePicture || undefined,
        service: selectedService,
        experience: parseInt(updateForm.experience),
        description: updateForm.description
      });
      
      setUpdateForm({
        providerId: '',
        providerName: '',
        location: '',
        mobileNumber: '',
        email: '',
        profilePicture: '',
        serviceId: '',
        experience: '',
        description: ''
      });
      
      fetchProviders();
      alert('Provider updated successfully!');
    } catch (err) {
      console.error('Failed to update provider:', err);
      alert('Failed to update provider');
    }
  };

  const handleDeleteProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await adminAPI.deleteProvider(deleteId);
      setDeleteId('');
      fetchProviders();
      alert('Provider deleted successfully!');
    } catch (err) {
      console.error('Failed to delete provider:', err);
      alert('Failed to delete provider');
    }
  };

  const loadProviderForUpdate = (provider: Provider) => {
    setUpdateForm({
      providerId: provider.username,
      providerName: provider.providerName,
      location: provider.location,
      mobileNumber: provider.mobileNumber.toString(),
      email: provider.email || '',
      profilePicture: provider.profilePicture || '',
      serviceId: provider.service.serviceId,
      experience: provider.experience.toString(),
      description: provider.description
    });
    setActiveTab('update');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Admin" links={navLinks} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('list')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'list'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Provider List
              </button>
              <button
                onClick={() => setActiveTab('create')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'create'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Create Provider
              </button>
              <button
                onClick={() => setActiveTab('update')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'update'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Update Provider
              </button>
              <button
                onClick={() => setActiveTab('delete')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'delete'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Delete Provider
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'list' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-semibold">Provider List</h2>
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search by Provider ID"
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={searchId}
                        onChange={(e) => setSearchId(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Username
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Provider Name
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Mobile Number
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Email
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Service
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Experience
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredProviders.map((provider) => (
                        <tr key={provider.username} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {provider.username}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {provider.providerName}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {provider.mobileNumber}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {provider.email || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {provider.service.serviceName}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {provider.experience} years
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => loadProviderForUpdate(provider)}
                              className="text-blue-600 hover:text-blue-900 mr-3"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'create' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Create New Provider</h2>
                <form onSubmit={handleCreateProvider} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Username *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.username}
                        onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Password *
                      </label>
                      <input
                        type="password"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.password}
                        onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Provider Name *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.providerName}
                        onChange={(e) => setCreateForm({ ...createForm, providerName: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Location *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.location}
                        onChange={(e) => setCreateForm({ ...createForm, location: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Mobile Number *
                      </label>
                      <input
                        type="tel"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.mobileNumber}
                        onChange={(e) => setCreateForm({ ...createForm, mobileNumber: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email
                      </label>
                      <input
                        type="email"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.email}
                        onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Service *
                      </label>
                      <select
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.serviceId}
                        onChange={(e) => setCreateForm({ ...createForm, serviceId: e.target.value })}
                      >
                        <option value="">Select Service</option>
                        {services.map((service) => (
                          <option key={service.serviceId} value={service.serviceId}>
                            {service.serviceName}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Experience (Years) *
                      </label>
                      <input
                        type="number"
                        required
                        min="0"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={createForm.experience}
                        onChange={(e) => setCreateForm({ ...createForm, experience: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Profile Picture URL
                    </label>
                    <input
                      type="url"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={createForm.profilePicture}
                      onChange={(e) => setCreateForm({ ...createForm, profilePicture: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Description *
                    </label>
                    <textarea
                      required
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={createForm.description}
                      onChange={(e) => setCreateForm({ ...createForm, description: e.target.value })}
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
                  >
                    Create Provider
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'update' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Update Provider</h2>
                <form onSubmit={handleUpdateProvider} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Provider ID *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.providerId}
                        onChange={(e) => setUpdateForm({ ...updateForm, providerId: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Provider Name *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.providerName}
                        onChange={(e) => setUpdateForm({ ...updateForm, providerName: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Location *
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.location}
                        onChange={(e) => setUpdateForm({ ...updateForm, location: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Mobile Number *
                      </label>
                      <input
                        type="tel"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.mobileNumber}
                        onChange={(e) => setUpdateForm({ ...updateForm, mobileNumber: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email
                      </label>
                      <input
                        type="email"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.email}
                        onChange={(e) => setUpdateForm({ ...updateForm, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Service *
                      </label>
                      <select
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.serviceId}
                        onChange={(e) => setUpdateForm({ ...updateForm, serviceId: e.target.value })}
                      >
                        <option value="">Select Service</option>
                        {services.map((service) => (
                          <option key={service.serviceId} value={service.serviceId}>
                            {service.serviceName}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Experience (Years) *
                      </label>
                      <input
                        type="number"
                        required
                        min="0"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={updateForm.experience}
                        onChange={(e) => setUpdateForm({ ...updateForm, experience: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Profile Picture URL
                    </label>
                    <input
                      type="url"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={updateForm.profilePicture}
                      onChange={(e) => setUpdateForm({ ...updateForm, profilePicture: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Description *
                    </label>
                    <textarea
                      required
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={updateForm.description}
                      onChange={(e) => setUpdateForm({ ...updateForm, description: e.target.value })}
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
                  >
                    Update Provider
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'delete' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Delete Provider</h2>
                <form onSubmit={handleDeleteProvider} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Provider ID *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Enter provider ID to delete"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                      value={deleteId}
                      onChange={(e) => setDeleteId(e.target.value)}
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700"
                  >
                    Delete Provider
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminProviders;