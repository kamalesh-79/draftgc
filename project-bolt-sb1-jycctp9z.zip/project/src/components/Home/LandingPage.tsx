import React, { useState, useEffect } from 'react';
import { Search, Star, Users, Award, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { searchAPI, adminAPI } from '../../services/api';
import { Provider, ServiceEntity } from '../../types';

const LandingPage: React.FC = () => {
  const [searchLocation, setSearchLocation] = useState('');
  const [selectedService, setSelectedService] = useState('');
  const [services, setServices] = useState<ServiceEntity[]>([]);
  const [searchResults, setSearchResults] = useState<Provider[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const servicesData = await adminAPI.getAllServices();
      setServices(servicesData);
    } catch (err) {
      console.error('Failed to fetch services:', err);
    }
  };

  const handleSearch = async () => {
    if (!searchLocation) {
      alert('Please enter a location');
      return;
    }
    
    setLoading(true);
    try {
      let results: Provider[] = [];
      
      if (selectedService) {
        const selectedServiceName = services.find(s => s.serviceId === selectedService)?.serviceName;
        if (selectedServiceName) {
          results = await searchAPI.searchRelevant(searchLocation, selectedServiceName);
        }
      } else {
        results = await searchAPI.searchByLocation(searchLocation);
      }
      
      setSearchResults(results);
      setShowResults(true);
    } catch (err) {
      console.error('Search failed:', err);
      setSearchResults([]);
      setShowResults(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white" style={{ cursor: 'url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDJMMTMuMDkgOC4yNkwyMCA5TDEzLjA5IDE1Ljc0TDEyIDIyTDEwLjkxIDE1Ljc0TDQgOUwxMC45MSA4LjI2TDEyIDJaIiBmaWxsPSIjMzMzIi8+Cjwvc3ZnPgo="), auto' }}>
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">Helping Hand</h1>
            <div className="space-x-4">
              <Link
                to="/login"
                className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition-colors duration-200"
              >
                Login
              </Link>
              <Link
                to="/signup"
                className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition-colors duration-200"
              >
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Find Local Service Providers
          </h2>
          <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto">
            Connect with trusted professionals in your area for all your service needs. 
            From home repairs to personal services, we've got you covered.
          </p>

          {/* Search Section */}
          <div className="bg-white rounded-lg shadow-lg p-8 max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Service Type</label>
                <select
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                >
                  <option value="">All Services</option>
                  {services.map((service) => (
                    <option key={service.serviceId} value={service.serviceId}>
                      {service.serviceName}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <input
                  type="text"
                  placeholder="Enter your location"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={searchLocation}
                  onChange={(e) => setSearchLocation(e.target.value)}
                />
              </div>
              
              <div className="flex items-end">
                <button
                  onClick={handleSearch}
                  disabled={loading}
                  className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center justify-center transition-colors duration-200"
                >
                  <Search className="w-5 h-5 mr-2" />
                  {loading ? 'Searching...' : 'Search'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search Results */}
      {showResults && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h3 className="text-3xl font-bold text-gray-900 mb-8">
              {searchResults.length > 0 ? 'Here\'s What Top Services We Found For...' : 'No services found'}
            </h3>
            
            {searchResults.length > 0 ? (
              <div className="space-y-6">
                {searchResults.map((provider) => (
                  <div key={provider.username} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow duration-200">
                    <div className="flex items-start space-x-4">
                      <div className="w-16 h-16 bg-gray-200 rounded-lg flex-shrink-0"></div>
                      <div className="flex-1">
                        <h4 className="text-xl font-semibold text-gray-900">{provider.service.serviceName}</h4>
                        <p className="text-gray-600 mt-1">{provider.description}</p>
                        <div className="flex items-center mt-2">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="text-gray-600">{provider.rating}/5</span>
                          <span className="mx-2">•</span>
                          <span className="text-gray-600">{provider.location}</span>
                        </div>
                        <button className="mt-4 bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                          Know More
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600 text-lg">No services found for your search criteria.</p>
                <p className="text-gray-500 mt-2">Try searching with different location or service type.</p>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Our Top Performers */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-gray-900 mb-12 text-center">Our Top Performers</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg p-6 text-center shadow-md">
              <div className="w-20 h-20 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Users className="w-10 h-10 text-blue-600" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Expert Professionals</h4>
              <p className="text-gray-600">Skilled and verified service providers ready to help you.</p>
            </div>
            <div className="bg-white rounded-lg p-6 text-center shadow-md">
              <div className="w-20 h-20 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Star className="w-10 h-10 text-green-600" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Quality Service</h4>
              <p className="text-gray-600">Top-rated services with excellent customer satisfaction.</p>
            </div>
            <div className="bg-white rounded-lg p-6 text-center shadow-md">
              <div className="w-20 h-20 bg-purple-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Award className="w-10 h-10 text-purple-600" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Trusted Platform</h4>
              <p className="text-gray-600">Secure and reliable platform for all your service needs.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Hear From Our Customers */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-gray-900 mb-12">Hear From Our Customers</h3>
          <div className="bg-gray-50 rounded-lg p-8">
            <div className="flex items-start space-x-6">
              <div className="w-24 h-24 bg-gray-300 rounded-lg flex-shrink-0"></div>
              <div>
                <div className="flex items-center mb-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-5 h-5 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 text-lg mb-4">
                  "We hired this team to help us with our home renovation project. They were professional, 
                  efficient, and delivered excellent results. Highly recommended!"
                </p>
                <p className="text-gray-600 font-medium">- Sarah Johnson</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Explore More */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-gray-900 mb-12">Explore More</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <div className="h-48 bg-gray-200"></div>
              <div className="p-6">
                <h4 className="text-xl font-semibold mb-2">Home Cleaning Services</h4>
                <p className="text-gray-600 mb-4">Professional cleaning services for your home and office.</p>
                <Link to="/signup" className="text-blue-600 hover:text-blue-700 font-medium flex items-center">
                  Learn More <ArrowRight className="w-4 h-4 ml-1" />
                </Link>
              </div>
            </div>
            <div className="bg-white rounded-lg overflow-hidden shadow-md">
              <div className="h-48 bg-gray-200"></div>
              <div className="p-6">
                <h4 className="text-xl font-semibold mb-2">Handyman Services</h4>
                <p className="text-gray-600 mb-4">Expert repair and maintenance services for your property.</p>
                <Link to="/signup" className="text-blue-600 hover:text-blue-700 font-medium flex items-center">
                  Learn More <ArrowRight className="w-4 h-4 ml-1" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-lg font-semibold mb-4">Helping Hand</h4>
              <p className="text-gray-400">Connecting communities through trusted local services.</p>
            </div>
            <div>
              <h5 className="font-medium mb-4">Services</h5>
              <ul className="space-y-2 text-gray-400">
                <li>Home Cleaning</li>
                <li>Repairs</li>
                <li>Maintenance</li>
                <li>Personal Services</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium mb-4">Company</h5>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/about">About Us</Link></li>
                <li>Contact</li>
                <li>Careers</li>
                <li>Support</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium mb-4">Legal</h5>
              <ul className="space-y-2 text-gray-400">
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
                <li>Cookie Policy</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Helping Hand. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;