import React, { useState, useEffect } from 'react';
import { Edit, Star, Calendar, MapPin, Phone, Mail } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { customerAPI, bookingAPI } from '../../services/api';
import { Customer, Booking } from '../../types';
import { useAuth } from '../../context/AuthContext';

const CustomerProfile: React.FC = () => {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [activeTab, setActiveTab] = useState('details');
  const [isEditing, setIsEditing] = useState(false);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState<string>('');
  const [rating, setRating] = useState(5);
  const [editForm, setEditForm] = useState({
    customerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: ''
  });

  const { user } = useAuth();

  const navLinks = [
    { label: 'Home', path: '/customer/dashboard' },
    { label: 'Services', path: '/customer/services' },
    { label: 'My Profile', path: '/customer/profile' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    if (user) {
      fetchCustomerProfile();
      fetchBookings();
    }
  }, [user]);

  const fetchCustomerProfile = async () => {
    try {
      const username = localStorage.getItem('username') || 'defaultCustomer';
      const profile = await customerAPI.getProfile(username);
      setCustomer(profile);
      setEditForm({
        customerName: profile.customerName,
        location: profile.location,
        mobileNumber: profile.mobileNumber.toString(),
        email: profile.email || '',
        profilePicture: profile.profilePicture || ''
      });
    } catch (err) {
      console.error('Failed to fetch profile:', err);
    }
  };

  const fetchBookings = async () => {
    try {
      const username = localStorage.getItem('username') || 'defaultCustomer';
      const bookingsData = await bookingAPI.getBookedRequests(username);
      setBookings(bookingsData);
    } catch (err) {
      console.error('Failed to fetch bookings:', err);
    }
  };

  const handleUpdateProfile = async () => {
    try {
      const username = localStorage.getItem('username') || 'defaultCustomer';
      const updatedProfile = await customerAPI.updateCustomer(username, {
        username,
        ...editForm,
        mobileNumber: parseInt(editForm.mobileNumber)
      });
      setCustomer(updatedProfile);
      setIsEditing(false);
    } catch (err) {
      console.error('Failed to update profile:', err);
    }
  };

  const handleCompleteBooking = async (bookingId: string) => {
    try {
      await bookingAPI.completeService(bookingId);
      setSelectedBooking(bookingId);
      setShowRatingModal(true);
    } catch (err) {
      console.error('Failed to complete booking:', err);
    }
  };

  const handleRateProvider = async () => {
    try {
      const username = localStorage.getItem('username') || 'defaultCustomer';
      await customerAPI.rateProvider(username, selectedBooking, rating);
      setShowRatingModal(false);
      fetchBookings();
    } catch (err) {
      console.error('Failed to rate provider:', err);
    }
  };

  const handleRevokeBooking = async (bookingId: string) => {
    try {
      await bookingAPI.revokeBooking(bookingId);
      fetchBookings();
    } catch (err) {
      console.error('Failed to revoke booking:', err);
    }
  };

  if (!customer) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar title="GoLocal - Customer" links={navLinks} />
        <div className="flex justify-center items-center h-64">
          <div className="text-xl text-gray-600">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Customer" links={navLinks} />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md">
          {/* Profile Header */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-t-lg p-6 text-white">
            <div className="flex items-center">
              {customer.profilePicture ? (
                <img
                  src={customer.profilePicture}
                  alt={customer.customerName}
                  className="w-20 h-20 rounded-full object-cover mr-6"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-6">
                  <span className="text-2xl font-bold">
                    {customer.customerName.charAt(0)}
                  </span>
                </div>
              )}
              <div>
                <h1 className="text-3xl font-bold">{customer.customerName}</h1>
                <p className="text-blue-100 mt-1">Customer Profile</p>
                <div className="flex items-center mt-2">
                  <Star className="w-5 h-5 text-yellow-300 mr-1" />
                  <span className="text-blue-100">Rating: {customer.rating}/5</span>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('details')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'details'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Details
              </button>
              <button
                onClick={() => setActiveTab('bookings')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'bookings'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Booking History
              </button>
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {activeTab === 'details' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-semibold">Profile Details</h2>
                  <button
                    onClick={() => setIsEditing(!isEditing)}
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    {isEditing ? 'Cancel' : 'Edit Profile'}
                  </button>
                </div>

                {isEditing ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Customer Name
                        </label>
                        <input
                          type="text"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          value={editForm.customerName}
                          onChange={(e) => setEditForm({ ...editForm, customerName: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Location
                        </label>
                        <input
                          type="text"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          value={editForm.location}
                          onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Mobile Number
                        </label>
                        <input
                          type="tel"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          value={editForm.mobileNumber}
                          onChange={(e) => setEditForm({ ...editForm, mobileNumber: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          value={editForm.email}
                          onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Profile Picture URL
                      </label>
                      <input
                        type="url"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={editForm.profilePicture}
                        onChange={(e) => setEditForm({ ...editForm, profilePicture: e.target.value })}
                      />
                    </div>
                    <button
                      onClick={handleUpdateProfile}
                      className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
                    >
                      Save Changes
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Username</label>
                        <p className="mt-1 text-gray-900">{customer.username}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                        <p className="mt-1 text-gray-900">{customer.customerName}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Location</label>
                        <div className="flex items-center mt-1">
                          <MapPin className="w-4 h-4 text-gray-500 mr-2" />
                          <p className="text-gray-900">{customer.location}</p>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Mobile Number</label>
                        <div className="flex items-center mt-1">
                          <Phone className="w-4 h-4 text-gray-500 mr-2" />
                          <p className="text-gray-900">{customer.mobileNumber}</p>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Email</label>
                        <div className="flex items-center mt-1">
                          <Mail className="w-4 h-4 text-gray-500 mr-2" />
                          <p className="text-gray-900">{customer.email || 'Not provided'}</p>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Bookings</label>
                        <p className="mt-1 text-gray-900">{customer.noOfBookings}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'bookings' && (
              <div>
                <h2 className="text-2xl font-semibold mb-6">Booking History</h2>
                {bookings.length === 0 ? (
                  <p className="text-gray-600">No bookings found.</p>
                ) : (
                  <div className="space-y-4">
                    {bookings.map((booking) => (
                      <div key={booking.bookingId} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg">{booking.provider.providerName}</h3>
                            <p className="text-gray-600">{booking.typeOfJob}</p>
                            <div className="flex items-center mt-2 space-x-4">
                              <div className="flex items-center text-gray-600">
                                <Calendar className="w-4 h-4 mr-1" />
                                <span>{new Date(booking.dateTime).toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center text-gray-600">
                                <MapPin className="w-4 h-4 mr-1" />
                                <span>{booking.location}</span>
                              </div>
                            </div>
                            <p className="text-lg font-semibold text-green-600 mt-2">
                              ₹{booking.amountPaid}
                            </p>
                          </div>
                          <div className="flex flex-col items-end space-y-2">
                            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                              booking.status === 'COMPLETED' ? 'bg-green-100 text-green-800' :
                              booking.status === 'BOOKED' ? 'bg-blue-100 text-blue-800' :
                              booking.status === 'REQUESTED' ? 'bg-yellow-100 text-yellow-800' :
                              booking.status === 'REJECTED' ? 'bg-red-100 text-red-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {booking.status}
                            </span>
                            {booking.status === 'REQUESTED' && (
                              <button
                                onClick={() => handleRevokeBooking(booking.bookingId)}
                                className="px-3 py-1 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm"
                              >
                                Revoke
                              </button>
                            )}
                            {booking.status === 'BOOKED' && (
                              <button
                                onClick={() => handleCompleteBooking(booking.bookingId)}
                                className="px-3 py-1 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"
                              >
                                Completed
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Rating Modal */}
      {showRatingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-semibold mb-4">Rate Provider</h3>
            <p className="text-gray-600 mb-4">How would you rate this service?</p>
            <div className="flex items-center space-x-2 mb-6">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  className={`text-2xl ${star <= rating ? 'text-yellow-500' : 'text-gray-300'}`}
                >
                  ★
                </button>
              ))}
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowRatingModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleRateProvider}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Submit Rating
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerProfile;