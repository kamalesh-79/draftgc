import React, { useState, useEffect } from 'react';
import { Search, Star, MapPin, Phone, Mail, Filter } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { searchAPI, adminAPI, bookingAPI } from '../../services/api';
import { Provider, ServiceEntity } from '../../types';

const Services: React.FC = () => {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [services, setServices] = useState<ServiceEntity[]>([]);
  const [filteredProviders, setFilteredProviders] = useState<Provider[]>([]);
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  
  // Filters
  const [filters, setFilters] = useState({
    providerId: '',
    rating: '',
    location: '',
    serviceType: ''
  });

  // Booking form
  const [bookingForm, setBookingForm] = useState({
    location: '',
    dateTime: '',
    amount: ''
  });

  const navLinks = [
    { label: 'Home', path: '/customer/dashboard' },
    { label: 'Services', path: '/customer/services' },
    { label: 'My Profile', path: '/customer/profile' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchServices();
    fetchAllProviders();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [providers, filters]);

  const fetchServices = async () => {
    try {
      const servicesData = await adminAPI.getAllServices();
      setServices(servicesData);
    } catch (err) {
      console.error('Failed to fetch services:', err);
    }
  };

  const fetchAllProviders = async () => {
    try {
      const providersData = await adminAPI.getAllProviders();
      setProviders(providersData);
    } catch (err) {
      console.error('Failed to fetch providers:', err);
    }
  };

  const applyFilters = () => {
    let filtered = [...providers];

    if (filters.providerId) {
      filtered = filtered.filter(p => 
        p.username.toLowerCase().includes(filters.providerId.toLowerCase())
      );
    }

    if (filters.rating) {
      const minRating = parseInt(filters.rating);
      filtered = filtered.filter(p => p.rating >= minRating);
    }

    if (filters.location) {
      filtered = filtered.filter(p => 
        p.location.toLowerCase().includes(filters.location.toLowerCase())
      );
    }

    if (filters.serviceType) {
      filtered = filtered.filter(p => 
        p.service.serviceName.toLowerCase().includes(filters.serviceType.toLowerCase())
      );
    }

    setFilteredProviders(filtered);
  };

  const handleBookService = (provider: Provider) => {
    setSelectedProvider(provider);
    setShowBookingModal(true);
  };

  const handleSubmitBooking = async () => {
    if (!selectedProvider) return;

    try {
      const customerId = localStorage.getItem('username') || 'customer1';
      const bookingData = {
        providerId: selectedProvider.username,
        location: bookingForm.location,
        dateTime: bookingForm.dateTime,
        amount: parseFloat(bookingForm.amount)
      };

      await bookingAPI.bookRequest(
        selectedProvider.service.serviceName,
        customerId,
        bookingData
      );

      setShowBookingModal(false);
      setBookingForm({ location: '', dateTime: '', amount: '' });
      alert('Booking request sent successfully!');
    } catch (err) {
      console.error('Failed to book service:', err);
      alert('Failed to book service. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Services" links={navLinks} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex items-center mb-4">
            <Filter className="w-5 h-5 mr-2 text-gray-600" />
            <h2 className="text-xl font-semibold">Search Filters</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Provider ID
              </label>
              <input
                type="text"
                placeholder="Search by provider ID"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.providerId}
                onChange={(e) => setFilters({ ...filters, providerId: e.target.value })}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Minimum Rating
              </label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.rating}
                onChange={(e) => setFilters({ ...filters, rating: e.target.value })}
              >
                <option value="">All Ratings</option>
                <option value="1">1+ Stars</option>
                <option value="2">2+ Stars</option>
                <option value="3">3+ Stars</option>
                <option value="4">4+ Stars</option>
                <option value="5">5 Stars</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Location
              </label>
              <input
                type="text"
                placeholder="Search by location"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.location}
                onChange={(e) => setFilters({ ...filters, location: e.target.value })}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Service Type
              </label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={filters.serviceType}
                onChange={(e) => setFilters({ ...filters, serviceType: e.target.value })}
              >
                <option value="">All Services</option>
                {services.map((service) => (
                  <option key={service.serviceId} value={service.serviceName}>
                    {service.serviceName}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Services Grid */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-semibold mb-6">Available Services</h2>
          
          {filteredProviders.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No services found matching your criteria.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProviders.map((provider) => (
                <div key={provider.username} className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow duration-200">
                  <div className="flex items-center mb-4">
                    {provider.profilePicture ? (
                      <img
                        src={provider.profilePicture}
                        alt={provider.providerName}
                        className="w-16 h-16 rounded-full object-cover mr-4"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-gray-300 flex items-center justify-center mr-4">
                        <span className="text-gray-600 font-semibold text-lg">
                          {provider.providerName.charAt(0)}
                        </span>
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold text-lg">{provider.providerName}</h3>
                      <p className="text-blue-600 font-medium">{provider.service.serviceName}</p>
                      <div className="flex items-center mt-1">
                        <Star className="w-4 h-4 text-yellow-500 mr-1" />
                        <span className="text-gray-600">{provider.rating}/5</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-4 h-4 mr-2" />
                      <span>{provider.location}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Phone className="w-4 h-4 mr-2" />
                      <span>{provider.mobileNumber}</span>
                    </div>
                    {provider.email && (
                      <div className="flex items-center text-gray-600">
                        <Mail className="w-4 h-4 mr-2" />
                        <span className="truncate">{provider.email}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="mb-4">
                    <p className="text-gray-700 text-sm line-clamp-3">{provider.description}</p>
                  </div>
                  
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-gray-600">
                      {provider.experience} years experience
                    </span>
                    <span className="text-sm text-gray-600">
                      Booked {provider.noOfTimesBooked} times
                    </span>
                  </div>
                  
                  <button
                    onClick={() => handleBookService(provider)}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                  >
                    Book Service
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Booking Modal */}
      {showBookingModal && selectedProvider && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-2xl font-semibold mb-4">Book Service</h3>
            
            <div className="mb-4">
              <h4 className="font-medium text-lg">{selectedProvider.providerName}</h4>
              <p className="text-gray-600">{selectedProvider.service.serviceName}</p>
              <p className="text-gray-600">{selectedProvider.location}</p>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Service Location
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={bookingForm.location}
                  onChange={(e) => setBookingForm({ ...bookingForm, location: e.target.value })}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Preferred Date & Time
                </label>
                <input
                  type="datetime-local"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={bookingForm.dateTime}
                  onChange={(e) => setBookingForm({ ...bookingForm, dateTime: e.target.value })}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Expected Amount (₹)
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="0.01"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={bookingForm.amount}
                  onChange={(e) => setBookingForm({ ...bookingForm, amount: e.target.value })}
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowBookingModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitBooking}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Book Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Services;