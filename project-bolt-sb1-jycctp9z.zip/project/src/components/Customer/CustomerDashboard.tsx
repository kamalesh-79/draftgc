import React, { useState, useEffect } from 'react';
import { Search, Star, MapPin, Phone, Mail } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { searchAPI, adminAPI } from '../../services/api';
import { Provider, ServiceEntity } from '../../types';

const CustomerDashboard: React.FC = () => {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [services, setServices] = useState<ServiceEntity[]>([]);
  const [searchLocation, setSearchLocation] = useState('');
  const [selectedService, setSelectedService] = useState('');
  const [loading, setLoading] = useState(false);

  const navLinks = [
    { label: 'Home', path: '/customer/dashboard' },
    { label: 'Services', path: '/customer/services' },
    { label: 'My Profile', path: '/customer/profile' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const servicesData = await adminAPI.getAllServices();
      setServices(servicesData);
    } catch (err) {
      console.error('Failed to fetch services:', err);
    }
  };

  const handleSearch = async () => {
    if (!searchLocation) return;
    
    setLoading(true);
    try {
      let results: Provider[] = [];
      
      if (selectedService) {
        results = await searchAPI.searchRelevant(searchLocation, selectedService);
      } else {
        results = await searchAPI.searchByLocation(searchLocation);
      }
      
      setProviders(results);
    } catch (err) {
      console.error('Search failed:', err);
      setProviders([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Customer" links={navLinks} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg p-8 text-white mb-8">
          <h1 className="text-4xl font-bold mb-4">Find Local Service Providers</h1>
          <p className="text-xl">Connect with skilled professionals in your area</p>
        </div>

        {/* Search Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-4">Search Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Service Type</label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={selectedService}
                onChange={(e) => setSelectedService(e.target.value)}
              >
                <option value="">All Services</option>
                {services.map((service) => (
                  <option key={service.serviceId} value={service.serviceName}>
                    {service.serviceName}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
              <input
                type="text"
                placeholder="Enter your location"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchLocation}
                onChange={(e) => setSearchLocation(e.target.value)}
              />
            </div>
            
            <div className="flex items-end">
              <button
                onClick={handleSearch}
                disabled={loading}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center justify-center"
              >
                <Search className="w-5 h-5 mr-2" />
                {loading ? 'Searching...' : 'Search'}
              </button>
            </div>
          </div>
        </div>

        {/* Promotional Slideshow */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
              <h3 className="text-xl font-semibold mb-2">Trusted Professionals</h3>
              <p>All our service providers are verified and rated by customers</p>
            </div>
            <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
              <h3 className="text-xl font-semibold mb-2">Quick Booking</h3>
              <p>Book services instantly and get work done at your convenience</p>
            </div>
            <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
              <h3 className="text-xl font-semibold mb-2">24/7 Support</h3>
              <p>Our customer support team is always here to help you</p>
            </div>
          </div>
        </div>

        {/* Search Results */}
        {providers.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-6">Available Service Providers</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {providers.map((provider) => (
                <div key={provider.username} className="border border-gray-200 rounded-lg p-4 hover:shadow-lg transition-shadow duration-200">
                  <div className="flex items-center mb-4">
                    {provider.profilePicture ? (
                      <img
                        src={provider.profilePicture}
                        alt={provider.providerName}
                        className="w-12 h-12 rounded-full object-cover mr-3"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center mr-3">
                        <span className="text-gray-600 font-semibold">
                          {provider.providerName.charAt(0)}
                        </span>
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold text-lg">{provider.providerName}</h3>
                      <p className="text-gray-600">{provider.service.serviceName}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-4 h-4 mr-2" />
                      <span>{provider.location}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Phone className="w-4 h-4 mr-2" />
                      <span>{provider.mobileNumber}</span>
                    </div>
                    {provider.email && (
                      <div className="flex items-center text-gray-600">
                        <Mail className="w-4 h-4 mr-2" />
                        <span>{provider.email}</span>
                      </div>
                    )}
                    <div className="flex items-center text-gray-600">
                      <Star className="w-4 h-4 mr-2 text-yellow-500" />
                      <span>Rating: {provider.rating}/5</span>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <p className="text-gray-700 text-sm">{provider.description}</p>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">
                      {provider.experience} years experience
                    </span>
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
                      Book Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* About Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mt-8">
          <h2 className="text-2xl font-semibold mb-4">About GoLocal</h2>
          <p className="text-gray-700 leading-relaxed">
            GoLocal is your trusted platform for finding reliable local service providers. 
            We connect customers with skilled professionals in their area, making it easy to 
            get quality services at competitive prices. Our platform ensures all providers 
            are verified and rated by genuine customers for your peace of mind.
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">GoLocal</h3>
            <p className="text-gray-300">Connecting communities through trusted services</p>
            <p className="text-gray-400 mt-4">&copy; 2024 GoLocal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CustomerDashboard;