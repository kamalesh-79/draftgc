import React, { useState, useEffect } from 'react';
import { Calendar, Star, Users, CheckCircle } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { bookingAPI, providerAPI } from '../../services/api';
import { Booking, Provider } from '../../types';

const ProviderDashboard: React.FC = () => {
  const [provider, setProvider] = useState<Provider | null>(null);
  const [requests, setRequests] = useState<Booking[]>([]);
  const [stats, setStats] = useState({
    totalRequests: 0,
    completedJobs: 0,
    averageRating: 0
  });

  const navLinks = [
    { label: 'Home', path: '/provider/dashboard' },
    { label: 'Profile', path: '/provider/profile' },
    { label: 'Book Requests', path: '/provider/requests' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchProviderData();
    fetchRequests();
  }, []);

  const fetchProviderData = async () => {
    try {
      const username = localStorage.getItem('username') || 'provider1';
      const providerData = await providerAPI.getProfile(username);
      setProvider(providerData);
      
      setStats({
        totalRequests: providerData.noOfTimesBooked,
        completedJobs: 0, // This would need to be calculated from bookings
        averageRating: providerData.rating
      });
    } catch (err) {
      console.error('Failed to fetch provider data:', err);
    }
  };

  const fetchRequests = async () => {
    try {
      const username = localStorage.getItem('username') || 'provider1';
      const requestsData = await bookingAPI.getAllReceivedRequests(username);
      setRequests(requestsData);
    } catch (err) {
      console.error('Failed to fetch requests:', err);
    }
  };

  if (!provider) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar title="GoLocal - Provider" links={navLinks} />
        <div className="flex justify-center items-center h-64">
          <div className="text-xl text-gray-600">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Provider" links={navLinks} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg p-8 text-white mb-8">
          <div className="flex items-center">
            {provider.profilePicture ? (
              <img
                src={provider.profilePicture}
                alt={provider.providerName}
                className="w-16 h-16 rounded-full object-cover mr-6"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-6">
                <span className="text-2xl font-bold">
                  {provider.providerName.charAt(0)}
                </span>
              </div>
            )}
            <div>
              <h1 className="text-3xl font-bold">Welcome back, {provider.providerName}!</h1>
              <p className="text-green-100 mt-1">{provider.service.serviceName} • {provider.location}</p>
              <div className="flex items-center mt-2">
                <Star className="w-5 h-5 text-yellow-300 mr-1" />
                <span className="text-green-100">{provider.rating}/5 Rating</span>
                <span className="mx-2">•</span>
                <span className="text-green-100">{provider.experience} years experience</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Calendar className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h3 className="text-2xl font-bold text-gray-900">{stats.totalRequests}</h3>
                <p className="text-gray-600">Total Bookings</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <CheckCircle className="w-8 h-8 text-green-600 mr-3" />
              <div>
                <h3 className="text-2xl font-bold text-gray-900">{requests.filter(r => r.status === 'COMPLETED').length}</h3>
                <p className="text-gray-600">Completed Jobs</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Star className="w-8 h-8 text-yellow-500 mr-3" />
              <div>
                <h3 className="text-2xl font-bold text-gray-900">{stats.averageRating}/5</h3>
                <p className="text-gray-600">Average Rating</p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Requests */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-6">Recent Service Requests</h2>
          {requests.length === 0 ? (
            <p className="text-gray-600 text-center py-8">No service requests yet.</p>
          ) : (
            <div className="space-y-4">
              {requests.slice(0, 5).map((request) => (
                <div key={request.bookingId} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg">{request.customer?.customerName || 'Customer'}</h3>
                      <p className="text-gray-600">{request.typeOfJob}</p>
                      <p className="text-gray-600">{request.location}</p>
                      <p className="text-sm text-gray-500">
                        {new Date(request.dateTime).toLocaleDateString()} at {new Date(request.dateTime).toLocaleTimeString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        request.status === 'COMPLETED' ? 'bg-green-100 text-green-800' :
                        request.status === 'BOOKED' ? 'bg-blue-100 text-blue-800' :
                        request.status === 'REQUESTED' ? 'bg-yellow-100 text-yellow-800' :
                        request.status === 'REJECTED' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {request.status}
                      </span>
                      <p className="text-lg font-semibold text-green-600 mt-2">
                        ₹{request.amountPaid}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Promotional Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
            <h3 className="text-xl font-semibold mb-2">Grow Your Business</h3>
            <p className="mb-4">Accept more bookings and increase your earnings with our platform.</p>
            <button className="bg-white text-purple-600 px-4 py-2 rounded-lg font-medium hover:bg-gray-100">
              View Tips
            </button>
          </div>
          
          <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
            <h3 className="text-xl font-semibold mb-2">Customer Reviews</h3>
            <p className="mb-4">Maintain high ratings by providing excellent service quality.</p>
            <button className="bg-white text-orange-600 px-4 py-2 rounded-lg font-medium hover:bg-gray-100">
              View Reviews
            </button>
          </div>
        </div>

        {/* About Section */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-semibold mb-4">About Your Service</h2>
          <p className="text-gray-700 leading-relaxed">
            {provider.description}
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">GoLocal Provider</h3>
            <p className="text-gray-300">Grow your business with trusted customers</p>
            <p className="text-gray-400 mt-4">&copy; 2024 GoLocal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ProviderDashboard;