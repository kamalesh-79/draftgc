import React, { useState, useEffect } from 'react';
import { Edit, Star, MapPin, Phone, Mail, Briefcase } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { providerAPI } from '../../services/api';
import { Provider } from '../../types';

const ProviderProfile: React.FC = () => {
  const [provider, setProvider] = useState<Provider | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    providerName: '',
    location: '',
    mobileNumber: '',
    email: '',
    profilePicture: '',
    experience: '',
    description: ''
  });

  const navLinks = [
    { label: 'Home', path: '/provider/dashboard' },
    { label: 'Profile', path: '/provider/profile' },
    { label: 'Book Requests', path: '/provider/requests' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchProviderProfile();
  }, []);

  const fetchProviderProfile = async () => {
    try {
      const username = localStorage.getItem('username') || 'provider1';
      const profile = await providerAPI.getProfile(username);
      setProvider(profile);
      setEditForm({
        providerName: profile.providerName,
        location: profile.location,
        mobileNumber: profile.mobileNumber.toString(),
        email: profile.email || '',
        profilePicture: profile.profilePicture || '',
        experience: profile.experience.toString(),
        description: profile.description
      });
    } catch (err) {
      console.error('Failed to fetch profile:', err);
    }
  };

  const handleUpdateProfile = async () => {
    try {
      const username = localStorage.getItem('username') || 'provider1';
      const updatedProfile = await providerAPI.updateProvider(username, {
        username,
        ...editForm,
        mobileNumber: parseInt(editForm.mobileNumber),
        experience: parseInt(editForm.experience),
        service: provider?.service
      });
      setProvider(updatedProfile);
      setIsEditing(false);
    } catch (err) {
      console.error('Failed to update profile:', err);
    }
  };

  if (!provider) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar title="GoLocal - Provider" links={navLinks} />
        <div className="flex justify-center items-center h-64">
          <div className="text-xl text-gray-600">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Provider" links={navLinks} />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md">
          {/* Profile Header */}
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-t-lg p-6 text-white">
            <div className="flex items-center">
              {provider.profilePicture ? (
                <img
                  src={provider.profilePicture}
                  alt={provider.providerName}
                  className="w-20 h-20 rounded-full object-cover mr-6"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-6">
                  <span className="text-2xl font-bold">
                    {provider.providerName.charAt(0)}
                  </span>
                </div>
              )}
              <div>
                <h1 className="text-3xl font-bold">{provider.providerName}</h1>
                <p className="text-green-100 mt-1">{provider.service.serviceName}</p>
                <div className="flex items-center mt-2">
                  <Star className="w-5 h-5 text-yellow-300 mr-1" />
                  <span className="text-green-100">Rating: {provider.rating}/5</span>
                  <span className="mx-2">•</span>
                  <span className="text-green-100">{provider.experience} years experience</span>
                </div>
              </div>
            </div>
          </div>

          {/* Profile Content */}
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Profile Details</h2>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Edit className="w-4 h-4 mr-2" />
                {isEditing ? 'Cancel' : 'Edit Profile'}
              </button>
            </div>

            {isEditing ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Provider Name
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={editForm.providerName}
                      onChange={(e) => setEditForm({ ...editForm, providerName: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Location
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={editForm.location}
                      onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Mobile Number
                    </label>
                    <input
                      type="tel"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={editForm.mobileNumber}
                      onChange={(e) => setEditForm({ ...editForm, mobileNumber: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={editForm.email}
                      onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Experience (Years)
                    </label>
                    <input
                      type="number"
                      min="0"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={editForm.experience}
                      onChange={(e) => setEditForm({ ...editForm, experience: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Profile Picture URL
                  </label>
                  <input
                    type="url"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                    value={editForm.profilePicture}
                    onChange={(e) => setEditForm({ ...editForm, profilePicture: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                    value={editForm.description}
                    onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  />
                </div>
                <button
                  onClick={handleUpdateProfile}
                  className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
                >
                  Save Changes
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Username</label>
                    <p className="mt-1 text-gray-900">{provider.username}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Provider Name</label>
                    <p className="mt-1 text-gray-900">{provider.providerName}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Location</label>
                    <div className="flex items-center mt-1">
                      <MapPin className="w-4 h-4 text-gray-500 mr-2" />
                      <p className="text-gray-900">{provider.location}</p>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Service Type</label>
                    <div className="flex items-center mt-1">
                      <Briefcase className="w-4 h-4 text-gray-500 mr-2" />
                      <p className="text-gray-900">{provider.service.serviceName}</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Mobile Number</label>
                    <div className="flex items-center mt-1">
                      <Phone className="w-4 h-4 text-gray-500 mr-2" />
                      <p className="text-gray-900">{provider.mobileNumber}</p>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Email</label>
                    <div className="flex items-center mt-1">
                      <Mail className="w-4 h-4 text-gray-500 mr-2" />
                      <p className="text-gray-900">{provider.email || 'Not provided'}</p>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Experience</label>
                    <p className="mt-1 text-gray-900">{provider.experience} years</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Times Booked</label>
                    <p className="mt-1 text-gray-900">{provider.noOfTimesBooked}</p>
                  </div>
                </div>
              </div>
            )}

            {!isEditing && (
              <div className="mt-8">
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <p className="text-gray-900 leading-relaxed">{provider.description}</p>
              </div>
            )}
          </div>
        </div>

        {/* Previous Works Section */}
        <div className="bg-white rounded-lg shadow-md mt-8 p-6">
          <h2 className="text-2xl font-semibold mb-4">Previous Works</h2>
          <div className="text-center py-8">
            <p className="text-gray-600">Work history will be displayed here once you complete services.</p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProviderProfile;