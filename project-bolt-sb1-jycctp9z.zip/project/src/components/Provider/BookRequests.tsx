import React, { useState, useEffect } from 'react';
import { Calendar, MapPin, Star, Check, X } from 'lucide-react';
import Navbar from '../Layout/Navbar';
import { bookingAPI, providerAPI } from '../../services/api';
import { Booking } from '../../types';

const BookRequests: React.FC = () => {
  const [requests, setRequests] = useState<Booking[]>([]);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState<string>('');
  const [rating, setRating] = useState(5);

  const navLinks = [
    { label: 'Home', path: '/provider/dashboard' },
    { label: 'Profile', path: '/provider/profile' },
    { label: 'Book Requests', path: '/provider/requests' },
    { label: 'About', path: '/about' }
  ];

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    try {
      const username = localStorage.getItem('username') || 'provider1';
      const requestsData = await bookingAPI.getAllReceivedRequests(username);
      setRequests(requestsData);
    } catch (err) {
      console.error('Failed to fetch requests:', err);
    }
  };

  const handleAcceptRequest = async (bookingId: string) => {
    try {
      await bookingAPI.acceptRequest(bookingId);
      fetchRequests();
    } catch (err) {
      console.error('Failed to accept request:', err);
    }
  };

  const handleRejectRequest = async (bookingId: string) => {
    try {
      await bookingAPI.rejectRequest(bookingId);
      fetchRequests();
    } catch (err) {
      console.error('Failed to reject request:', err);
    }
  };

  const handleCompleteService = async (bookingId: string) => {
    try {
      await bookingAPI.completeService(bookingId);
      setSelectedBooking(bookingId);
      setShowRatingModal(true);
    } catch (err) {
      console.error('Failed to complete service:', err);
    }
  };

  const handleRateCustomer = async () => {
    try {
      const username = localStorage.getItem('username') || 'provider1';
      await providerAPI.rateCustomer(username, selectedBooking, rating);
      setShowRatingModal(false);
      fetchRequests();
    } catch (err) {
      console.error('Failed to rate customer:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar title="GoLocal - Provider" links={navLinks} />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Service Requests</h1>
          
          {requests.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No service requests yet.</p>
              <p className="text-gray-500 mt-2">Requests from customers will appear here.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {requests.map((request) => (
                <div key={request.bookingId} className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow duration-200">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center mr-4">
                          <span className="text-white font-semibold">
                            {request.customer?.customerName?.charAt(0) || 'C'}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold">{request.customer?.customerName || 'Customer'}</h3>
                          <p className="text-gray-600">{request.typeOfJob}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center text-gray-600">
                          <MapPin className="w-5 h-5 mr-2" />
                          <span>{request.location}</span>
                        </div>
                        <div className="flex items-center text-gray-600">
                          <Calendar className="w-5 h-5 mr-2" />
                          <span>{new Date(request.dateTime).toLocaleDateString()} at {new Date(request.dateTime).toLocaleTimeString()}</span>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-2xl font-bold text-green-600">₹{request.amountPaid}</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col items-end space-y-3">
                      <span className={`px-4 py-2 rounded-full text-sm font-medium ${
                        request.status === 'COMPLETED' ? 'bg-green-100 text-green-800' :
                        request.status === 'BOOKED' ? 'bg-blue-100 text-blue-800' :
                        request.status === 'REQUESTED' ? 'bg-yellow-100 text-yellow-800' :
                        request.status === 'REJECTED' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {request.status}
                      </span>
                      
                      {request.status === 'REQUESTED' && (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleAcceptRequest(request.bookingId)}
                            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                          >
                            <Check className="w-4 h-4 mr-1" />
                            Accept
                          </button>
                          <button
                            onClick={() => handleRejectRequest(request.bookingId)}
                            className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200"
                          >
                            <X className="w-4 h-4 mr-1" />
                            Reject
                          </button>
                        </div>
                      )}
                      
                      {request.status === 'BOOKED' && (
                        <button
                          onClick={() => handleCompleteService(request.bookingId)}
                          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
                        >
                          <Check className="w-4 h-4 mr-1" />
                          Mark Complete
                        </button>
                      )}
                    </div>
                  </div>
                  
                  {/* Customer Details */}
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <h4 className="font-medium text-gray-900 mb-2">Customer Details:</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                      <div>Mobile: {request.customer?.mobileNumber || 'Not available'}</div>
                      <div>Email: {request.customer?.email || 'Not available'}</div>
                      <div>Location: {request.customer?.location || 'Not available'}</div>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-500 mr-1" />
                        Rating: {request.customer?.rating || 0}/5
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Rating Modal */}
      {showRatingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-semibold mb-4">Rate Customer</h3>
            <p className="text-gray-600 mb-4">How would you rate this customer?</p>
            <div className="flex items-center space-x-2 mb-6">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  className={`text-2xl ${star <= rating ? 'text-yellow-500' : 'text-gray-300'}`}
                >
                  ★
                </button>
              ))}
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowRatingModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleRateCustomer}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Submit Rating
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BookRequests;