import axios from 'axios';
import { AuthResponse, LoginRequest, RegisterCustomerRequest, RegisterProviderRequest, Customer, Provider, ServiceEntity, Booking, BookProvider } from '../types';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth API calls
export const authAPI = {
  login: async (loginData: LoginRequest): Promise<AuthResponse> => {
    const response = await api.post('/auth/login', loginData);
    return response.data;
  },

  registerCustomer: async (registerData: RegisterCustomerRequest) => {
    const response = await api.post('/auth/register-customer', registerData);
    return response.data;
  },

  registerProvider: async (registerData: RegisterProviderRequest) => {
    const response = await api.post('/auth/register-provider', registerData);
    return response.data;
  },

  registerAdmin: async (secretKey: string, registerData: any) => {
    const response = await api.post(`/auth/register-admin/${secretKey}`, registerData);
    return response.data;
  },

  getMe: async () => {
    const response = await api.get('/auth/me');
    return response.data;
  }
};

// Admin API calls
export const adminAPI = {
  getAllUsers: async () => {
    const response = await api.get('/admin/get-users');
    return response.data;
  },

  getAllCustomers: async (): Promise<Customer[]> => {
    const response = await api.get('/admin/get-customers');
    return response.data;
  },

  getCustomerById: async (customerId: string): Promise<Customer> => {
    const response = await api.get(`/admin/get-customers/${customerId}`);
    return response.data;
  },

  createCustomer: async (customerData: RegisterCustomerRequest) => {
    const response = await api.post('/admin/create-customer', customerData);
    return response.data;
  },

  updateCustomer: async (customerId: string, customerData: any) => {
    const response = await api.put(`/admin/update-customer/${customerId}`, customerData);
    return response.data;
  },

  deleteCustomer: async (customerId: string) => {
    const response = await api.delete(`/admin/delete-customer/${customerId}`);
    return response.data;
  },

  getAllProviders: async (): Promise<Provider[]> => {
    const response = await api.get('/admin/get-providers');
    return response.data;
  },

  getProviderById: async (providerId: string): Promise<Provider> => {
    const response = await api.get(`/admin/get-providers/${providerId}`);
    return response.data;
  },

  createProvider: async (providerData: RegisterProviderRequest) => {
    const response = await api.post('/admin/create-provider', providerData);
    return response.data;
  },

  updateProvider: async (providerId: string, providerData: any) => {
    const response = await api.put(`/admin/update-provider/${providerId}`, providerData);
    return response.data;
  },

  deleteProvider: async (providerId: string) => {
    const response = await api.delete(`/admin/delete-provider/${providerId}`);
    return response.data;
  },

  getProvidersByLocation: async (location: string) => {
    const response = await api.get('/admin/get-provider-location', { params: { location } });
    return response.data;
  },

  getRelevantProviders: async (location: string, serviceName: string) => {
    const response = await api.get('/admin/get-provider-relevant', { params: { location, serviceName } });
    return response.data;
  },

  createService: async (serviceData: { serviceId: string; serviceName: string }) => {
    const response = await api.post('/admin/create-service', serviceData);
    return response.data;
  },

  getServiceById: async (serviceId: string): Promise<ServiceEntity> => {
    const response = await api.get(`/admin/get-service/${serviceId}`);
    return response.data;
  },

  getAllServices: async (): Promise<ServiceEntity[]> => {
    const response = await api.get('/admin/get-service');
    return response.data;
  },

  getAllBookings: async (): Promise<Booking[]> => {
    const response = await api.get('/admin/get-all-bookings');
    return response.data;
  },

  updatePassword: async (username: string, newPassword: string) => {
    const response = await api.put(`/admin/update-password/${username}/${newPassword}`);
    return response.data;
  }
};

// Booking API calls
export const bookingAPI = {
  bookRequest: async (typeOfJob: string, customerId: string, bookData: BookProvider) => {
    const response = await api.post(`/bookings/book-request/${typeOfJob}/${customerId}`, bookData);
    return response.data;
  },

  getBookedRequests: async (customerId: string): Promise<Booking[]> => {
    const response = await api.get(`/bookings/get-booked-requests/${customerId}`);
    return response.data;
  },

  revokeBooking: async (bookingId: string) => {
    const response = await api.put(`/bookings/revoke-booking/${bookingId}`);
    return response.data;
  },

  acceptRequest: async (bookingId: string) => {
    const response = await api.put(`/bookings/accept-request/${bookingId}`);
    return response.data;
  },

  rejectRequest: async (bookingId: string) => {
    const response = await api.put(`/bookings/reject-request/${bookingId}`);
    return response.data;
  },

  getAllReceivedRequests: async (providerId: string): Promise<Booking[]> => {
    const response = await api.get(`/bookings/all-received-requests/${providerId}`);
    return response.data;
  },

  completeService: async (bookingId: string) => {
    const response = await api.put(`/bookings/complete/${bookingId}`);
    return response.data;
  }
};

// Customer API calls
export const customerAPI = {
  updateCustomer: async (customerId: string, customerData: any) => {
    const response = await api.put(`/customer/update-customer/${customerId}`, customerData);
    return response.data;
  },

  rateProvider: async (customerId: string, bookingId: string, ratingValue: number) => {
    const response = await api.post(`/customer/rate-provider/${customerId}/${bookingId}/${ratingValue}`);
    return response.data;
  },

  getProfile: async (customerId: string): Promise<Customer> => {
    const response = await api.get(`/customer/get-profile/${customerId}`);
    return response.data;
  }
};

// Provider API calls
export const providerAPI = {
  updateProvider: async (providerId: string, providerData: any) => {
    const response = await api.put(`/provider/update-provider/${providerId}`, providerData);
    return response.data;
  },

  rateCustomer: async (providerId: string, bookingId: string, ratingValue: number) => {
    const response = await api.post(`/provider/rate-customer/${providerId}/${bookingId}/${ratingValue}`);
    return response.data;
  },

  getProfile: async (providerId: string): Promise<Provider> => {
    const response = await api.get(`/provider/get-profile/${providerId}`);
    return response.data;
  }
};

// Search API calls
export const searchAPI = {
  searchProvider: async (providerId: string): Promise<Provider> => {
    const response = await api.get(`/search/${providerId}`);
    return response.data;
  },

  searchByLocation: async (location: string): Promise<Provider[]> => {
    const response = await api.get(`/search/search-by-location/${location}`);
    return response.data;
  },

  searchRelevant: async (location: string, serviceType: string): Promise<Provider[]> => {
    const response = await api.get(`/search/search-relevant/${location}/${serviceType}`);
    return response.data;
  }
};