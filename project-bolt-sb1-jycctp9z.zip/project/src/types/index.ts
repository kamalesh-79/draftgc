export interface User {
  username: string;
  password: string;
  role: 'ROLE_CUSTOMER' | 'ROLE_PROVIDER' | 'ROLE_ADMIN';
  isDeleted: boolean;
}

export interface Customer {
  username: string;
  customerName: string;
  location: string;
  mobileNumber: number;
  email?: string;
  rating: number;
  profilePicture?: string;
  noOfBookings: number;
}

export interface Provider {
  username: string;
  providerName: string;
  location: string;
  mobileNumber: number;
  email?: string;
  rating: number;
  profilePicture?: string;
  service: ServiceEntity;
  experience: number;
  description: string;
  noOfTimesBooked: number;
}

export interface ServiceEntity {
  serviceId: string;
  serviceName: string;
  noOfProviders: number;
}

export interface Booking {
  bookingId: string;
  provider: Provider;
  customer: Customer;
  location: string;
  dateTime: string;
  amountPaid: number;
  typeOfJob: string;
  status: 'REQUESTED' | 'BOOKED' | 'REJECTED' | 'REVOKED' | 'COMPLETED';
}

export interface Rating {
  ratingId: string;
  booking: Booking;
  ratingByCustomer: number;
  ratingByProvider: number;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  role: 'ROLE_CUSTOMER' | 'ROLE_PROVIDER' | 'ROLE_ADMIN';
}

export interface RegisterCustomerRequest {
  username: string;
  password: string;
  role: 'ROLE_CUSTOMER';
  isDeleted: boolean;
  customerName: string;
  location: string;
  mobileNumber: number;
  email?: string;
  profilePicture?: string;
}

export interface RegisterProviderRequest {
  username: string;
  password: string;
  role: 'ROLE_PROVIDER';
  isDeleted: boolean;
  providerName: string;
  location: string;
  mobileNumber: number;
  email?: string;
  profilePicture?: string;
  service: ServiceEntity;
  experience: number;
  description: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface BookProvider {
  providerId: string;
  location: string;
  dateTime: string;
  amount: number;
}