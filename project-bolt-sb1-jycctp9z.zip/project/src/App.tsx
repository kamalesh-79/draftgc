import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

// Components
import Login from './components/Auth/Login';
import Signup from './components/Auth/Signup';
import LandingPage from './components/Home/LandingPage';
import About from './components/About';

// Customer Components
import CustomerDashboard from './components/Customer/CustomerDashboard';
import CustomerProfile from './components/Customer/CustomerProfile';
import Services from './components/Customer/Services';

// Provider Components
import ProviderDashboard from './components/Provider/ProviderDashboard';
import ProviderProfile from './components/Provider/ProviderProfile';
import BookRequests from './components/Provider/BookRequests';

// Admin Components
import AdminDashboard from './components/Admin/AdminDashboard';
import AdminCustomers from './components/Admin/AdminCustomers';
import AdminProviders from './components/Admin/AdminProviders';
import AdminServices from './components/Admin/AdminServices';
import AdminBookings from './components/Admin/AdminBookings';
import AdminUpdatePassword from './components/Admin/AdminUpdatePassword';

// Protected Route Component
const ProtectedRoute: React.FC<{ children: React.ReactNode; allowedRoles: string[] }> = ({ 
  children, 
  allowedRoles 
}) => {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(user?.role || '')) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/about" element={<About />} />
            
            {/* Customer Routes */}
            <Route 
              path="/customer/dashboard" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_CUSTOMER']}>
                  <CustomerDashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/customer/profile" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_CUSTOMER']}>
                  <CustomerProfile />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/customer/services" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_CUSTOMER']}>
                  <Services />
                </ProtectedRoute>
              } 
            />
            
            {/* Provider Routes */}
            <Route 
              path="/provider/dashboard" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_PROVIDER']}>
                  <ProviderDashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/provider/profile" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_PROVIDER']}>
                  <ProviderProfile />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/provider/requests" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_PROVIDER']}>
                  <BookRequests />
                </ProtectedRoute>
              } 
            />
            
            {/* Admin Routes */}
            <Route 
              path="/admin/dashboard" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_ADMIN']}>
                  <AdminDashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/admin/customers" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_ADMIN']}>
                  <AdminCustomers />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/admin/providers" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_ADMIN']}>
                  <AdminProviders />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/admin/services" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_ADMIN']}>
                  <AdminServices />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/admin/bookings" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_ADMIN']}>
                  <AdminBookings />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/admin/update-password" 
              element={
                <ProtectedRoute allowedRoles={['ROLE_ADMIN']}>
                  <AdminUpdatePassword />
                </ProtectedRoute>
              } 
            />
            
            {/* Catch all route */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;